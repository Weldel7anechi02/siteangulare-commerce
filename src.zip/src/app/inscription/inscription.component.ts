import { Component } from '@angular/core';

@Component({
  selector: 'app-inscription',
  templateUrl: './inscription.component.html',
  styleUrls: ['./inscription.component.css'],
})
export class InscriptionComponent {
  products = [
    {
      category: 'Pull ',
      items: [
        { name: 'Pull 1', price: 50, src: 'assets/pull01.jpg', alt: 'Veste 1' },
        { name: 'Pull 2', price: 60, src: 'assets/pull02.avif', alt: 'Veste 2' },
        { name: 'Pull 3', price: 55, src: 'assets/pull03.webp', alt: 'Veste 3' },
        { name: 'Pull 4', price: 70, src: 'assets/pull04.jpg', alt: 'Veste 4' },
      ],
    },
    {
      category: 'Pantalons',
      items: [
        { name: 'Pantalon 1', price: 40, src: 'assets/pantalon01.webp', alt: 'Pantalon 1' },
        { name: 'Pantalon 2', price: 45, src: 'assets/pantalon02.jpeg', alt: 'Pantalon 2' },
        { name: 'Pantalon 3', price: 50, src: 'assets/pantalon03.jpeg', alt: 'Pantalon 3' },
        { name: 'Pantalon 4', price: 55, src: 'assets/pantalon04.webp', alt: 'Pantalon 4' },
      ],
    },
    {
      category: 'Chaussures',
      items: [
        { name: 'Chaussure 1', price: 80, src: 'assets/chausseur01.jpg', alt: 'Chaussure 1' },
        { name: 'Chaussure 2', price: 85, src: 'assets/chausseur02.jpg', alt: 'Chaussure 2' },
        { name: 'Chaussure 3', price: 90, src: 'assets/chausseur03.webp', alt: 'Chaussure 3' },
        { name: 'Chaussure 4', price: 95, src: 'assets/chausseur04.jpg', alt: 'Chaussure 4' },
      ],
    },
  ];

  cart: any[] = [];
  commandePassee: boolean = false;
  showCheckoutForm: boolean = false;

  orderData = {
    name: '',
    address: '',
    phone: '',
    email: ''
  };

  addToCart(product: any): void {
    this.cart.push(product);
    alert(`${product.name} a été ajouté au panier !`);
  }

  removeFromCart(index: number): void {
    this.cart.splice(index, 1);
    alert('Produit supprimé du panier.');
  }

  getTotalPrice(): number {
    return this.cart.reduce((total, item) => total + item.price, 0);
  }

  openCheckoutForm(): void {
    this.showCheckoutForm = true;
  }

  cancelCheckout(): void {
    this.showCheckoutForm = false;
  }

  submitOrder(): void {
    if (this.orderData.name && this.orderData.address && this.orderData.phone && this.orderData.email) {
      console.log('Commande envoyée:', this.orderData);
      this.commandePassee = true;
      this.cart = []; // vide le panier après la commande
      this.showCheckoutForm = false;
      alert('Commande passée avec succès !');
      // Réinitialiser le formulaire
      this.orderData = { name: '', address: '', phone: '', email: '' };
    } else {
      alert('Veuillez remplir tous les champs du formulaire.');
    }
  }
}
