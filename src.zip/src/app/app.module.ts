import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatCardModule } from '@angular/material/card';


import { AppComponent } from './app.component';
import { InscriptionComponent } from './inscription/inscription.component';
import { FooterComponent } from './footer/footer.component';
import { ContactComponent } from './contact/contact.component';
import { AboutComponent } from './about/about.component';
import { PanierComponent } from './panier/panier.component';
import { AccueilComponent } from './accueil/accueil.component';
import { CreationComponent } from './creation/creation.component';
import { LoginComponent } from './login/login.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';  // 👈 Ajout
import { ProductListComponent } from './product-list/product-list.component'; // 👈 Import added

const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'home', component: AccueilComponent },
  { path: 'signup', component: CreationComponent }, // 👈 Route for signup
  { path: 'login', component: LoginComponent },
  { path: 'inscription', component: InscriptionComponent },
  { path: 'prod', component: InscriptionComponent },
  { path: 'cnt', component: ContactComponent },
  { path: 'ab', component: AboutComponent },
  { path: 'log', component: InscriptionComponent }
];

@NgModule({
  declarations: [
    AppComponent,
    InscriptionComponent,
    FooterComponent,
    ContactComponent,
    AboutComponent,
    PanierComponent,
    AccueilComponent,
    LoginComponent,  // 👈 Ajout ici aussi
    ProductListComponent, // 👈 Declaration added
    CreationComponent
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    FormsModule,
    RouterModule.forRoot(routes),
    HttpClientModule,
    BrowserAnimationsModule,
    MatGridListModule, // Add this line
    MatCardModule      // Add this line
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA], // Add this line
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
