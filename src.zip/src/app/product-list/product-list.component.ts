import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  items: any[] = []; // Define the 'items' property

  constructor() {}

  ngOnInit(): void {
    // Mock data or fetch data dynamically
    this.items = [
      { name: 'Product 1', price: 100, src: 'assets/product1.jpg', alt: 'Product 1' },
      { name: 'Product 2', price: 200, src: 'assets/product2.jpg', alt: 'Product 2' },
      { name: 'Product 3', price: 300, src: 'assets/product3.jpg', alt: 'Product 3' }
    ];
  }
}
