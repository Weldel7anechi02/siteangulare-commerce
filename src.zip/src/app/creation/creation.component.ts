import { Component } from '@angular/core';

@Component({
  selector: 'app-creation',
  templateUrl: './creation.component.html',
  styleUrls: ['./creation.component.css']
})
export class CreationComponent {
  showSuccessMessage = false;

  constructor() {}

  onSubmit(): void {
    this.showSuccessMessage = true;
    console.log('Form submitted successfully!');
  }
}
