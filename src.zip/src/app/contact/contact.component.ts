import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent {
  adr: string = 'Tunis';
  tel: string = '25626998';
  email: string = 'contact@hannechi.com';

  messageEnvoye: boolean = false;
  formInvalid: boolean = false;

  onSubmit(contactForm: NgForm) {
    // Vérifie si le formulaire est invalide
    if (!contactForm.valid) {
      this.formInvalid = true;
      this.messageEnvoye = false;
      return;
    }

    // Simuler l'envoi du message avec succès
    console.log('Formulaire soumis !');
    this.messageEnvoye = true;
    this.formInvalid = false;

    // Réinitialiser le formulaire
    contactForm.resetForm();

    // Réinitialiser le message de succès après 5 secondes
    setTimeout(() => {
      this.messageEnvoye = false;
    }, 5000);
  }
}
