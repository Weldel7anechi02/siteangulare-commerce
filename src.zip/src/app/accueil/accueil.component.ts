import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-accueil',
  templateUrl: './accueil.component.html',
  styleUrls: ['./accueil.component.css']
})
export class AccueilComponent {
  afficherFormulaire = false;

  constructor(private router: Router) {}

  onSubmit() {
    // Ici, tu peux ajouter la logique pour enregistrer l’utilisateur
    console.log('Formulaire soumis');
    this.router.navigate(['/produit']); // Redirige vers la page Produit
  }
}
