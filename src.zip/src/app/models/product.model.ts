export interface Product {
  name: string;
  price: number;
  src: string;
  alt: string;
}